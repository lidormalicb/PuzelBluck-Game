/**
 *
 * @author Lidor Malich
 */
public class constants 
{
    //קבועים
    public static  final String WAIT_FOR_PARTNER="waitForPartner";
    public static  final String HAVE_PARTNER="have partner";
    public static  final String NEW_PARTNER="new partner";
    public static  final String WAIT_FOR_YOURE_TURN="waitForTurnToPlay";
    public static  final String YOU_TURN="UTurn";
    public static  final String YOU_TURN_WITHOUT_UPDATE_BORD="UTurnF";
    public static  final String GAME_OVER="#GameOver";
    public static  final String GAME_OVER_WITH_GET_STATE="#GameOver_State";
    public static  final String TIE_WITH_GET_STATE="#TIE_State";
    public static  final String TIE="#TIE";
    public static  final String CLOSE_CLIENT="#close";
    public static  final String CLIENT_WANT_EXIT="#want exit";
    public static  final String EXIT_AND_CLOSE_GAME="#exit";
    public static  final String SEND_BORD="sendBord";
}